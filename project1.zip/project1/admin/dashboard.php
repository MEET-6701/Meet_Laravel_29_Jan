		<!--left-fixed -navigation-->
	<title>
        dashboard
    </title>
    <?php
	include_once('header.php');
	?>		
	
    <?php
    include_once('footer.php');
    ?>