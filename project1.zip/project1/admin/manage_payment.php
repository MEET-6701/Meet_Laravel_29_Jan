<?php
    include_once('header.php');
?>
<title>Payment</title>
<div id="page-wrapper" style="min-height: 703px;">
<div class="main-page">
    <div class="tables">
        <h2 class="title1">Tables</h2>
        <div class="panel-body widget-shadow">
            <h4>Basic Table:</h4>
            <table class="table table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>peyment id</th>
                        <th>car id</th>
                        <th>method</th>
                        <th>customer </th>
                        <th>Created dt</th>
                        <th>Updated dt</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>me</td>
                        <td>eimcfpae</td>
                        <td>fnsoief</td>
                        <td>2441</td>
                        <td>2165</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>me</td>
                        <td>eimcfpae</td>
                        <td>fnsoief</td>
                        <td>2441</td>
                        <td>2165</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>me</td>
                        <td>fnsoief</td>
                        <td>eimcfpae</td>
                        <td>2441</td>
                        <td>2165</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>me</td>
                        <td>fnsoief</td>
                        <td>eimcfpae</td>
                        <td>2441</td>
                        <td>2165</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>      
</div>
</div>
<?php
    include_once('footer.php');
?>