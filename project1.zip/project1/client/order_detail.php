<?php
    include_once('header.php');
?>
    <title>Order Detail</title>
<?php
    include_once('footer.php');
?>